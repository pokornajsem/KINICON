import Header from "@/components/Header";
import ImageToVideoGenerator from "@/components/ImageToVideoGenerator";
import TeacherInfoButton from "@/components/TeacherInfoButton";
import EducationModule from "@/components/EducationModule";
import Footer from "@/components/Footer";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-stone-50 text-slate-900">
      <Header />
      <main className="mx-auto w-full max-w-5xl px-4 pb-14 pt-6 sm:pt-10">
        <section className="rounded-3xl bg-white/70 p-6 shadow-sm ring-1 ring-stone-200 backdrop-blur sm:p-8">
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
            Vítej ve svém digitálním ateliéru
          </h1>

          <p className="mt-3 text-slate-700">
            Tady se obrázky mění v pohyb. Pro děti je to jednoduché:
          </p>

          <ol className="mt-4 list-decimal space-y-2 pl-5 text-slate-800">
            <li>Nakresli obrázek.</li>
            <li>Nahraj ho.</li>
            <li>Oživ ho kouzlem.</li>
          </ol>

          <div className="mt-6 flex items-center gap-3">
            <TeacherInfoButton />
            <p className="text-sm text-slate-600">
              Bez sběru dat. Vše běží co nejvíc „uvnitř“ a jen pro účel
              generování.
            </p>
          </div>
        </section>

        <section className="mt-6">
          <ImageToVideoGenerator />
        </section>

        <section className="mt-6">
          <EducationModule />
        </section>
      </main>

      <Footer />
    </div>
  );
}

