import { NextRequest } from "next/server";

export const runtime = "nodejs";

type ApiSuccess = {
  ok: true;
  message?: string;
  videoBase64?: string;
  mimeType?: string;
};

type ApiFailure = {
  ok: false;
  message: string;
};

export async function POST(req: NextRequest): Promise<Response> {
  const formData = await req.formData();
  const image = formData.get("image");

  if (!(image instanceof File)) {
    const payload: ApiFailure = {
      ok: false,
      message: "Pošli prosím jeden obrázek (field `image`).",
    };
    return Response.json(payload, { status: 400 });
  }

  // Stateless: pracujeme jen s daty v paměti (bez ukládání na disk).
  const arrayBuffer = await image.arrayBuffer();
  const imageBase64 = Buffer.from(arrayBuffer).toString("base64");
  const mimeType = image.type || "image/png";

  const endpoint = process.env.IMAGE_TO_VIDEO_ENDPOINT;
  const apiKey = process.env.IMAGE_TO_VIDEO_API_KEY;
  const model = process.env.IMAGE_TO_VIDEO_MODEL;

  if (!endpoint) {
    const payload: ApiFailure = {
      ok: false,
      message:
        "Integrace není nakonfigurovaná. Vytvoř `IMAGE_TO_VIDEO_ENDPOINT` (a případně `IMAGE_TO_VIDEO_API_KEY`) v lokálním .env nebo ve Vercel Env.",
    };
    return Response.json(payload, { status: 501 });
  }

  try {
    // Pozn.: formát request/response se liší služba od služby.
    // Tohle je připravené rozhraní – uprav payload dle dokumentace vaší Image-to-Video služby.
    const payload = {
      model,
      prompt: "Vytvoř krátké video z dodaného obrázku.",
      image: {
        mimeType,
        base64: imageBase64,
      },
    };

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };
    if (apiKey) headers.Authorization = `Bearer ${apiKey}`;

    const upstream = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    });

    const text = await upstream.text();
    let upstreamJson: any = null;
    try {
      upstreamJson = JSON.parse(text);
    } catch {
      // Některé služby vrací i ne-JSON text.
    }

    if (!upstream.ok) {
      const message =
        (upstreamJson && (upstreamJson.error || upstreamJson.message)) ||
        `Upstream chyba: HTTP ${upstream.status}`;
      const failure: ApiFailure = { ok: false, message: String(message) };
      return Response.json(failure, { status: upstream.status });
    }

    const videoBase64 =
      upstreamJson?.videoBase64 ||
      upstreamJson?.video?.base64 ||
      upstreamJson?.result?.videoBase64 ||
      undefined;

    const upstreamMime =
      upstreamJson?.mimeType ||
      upstreamJson?.video?.mimeType ||
      upstreamJson?.result?.mimeType ||
      undefined;

    const success: ApiSuccess = {
      ok: true,
      message:
        upstreamJson?.message ||
        "Generování úspěšné (pokud upstream vrací videoBase64).",
      videoBase64,
      mimeType: upstreamMime,
    };

    return Response.json(success, { status: 200 });
  } catch (e) {
    const failure: ApiFailure = {
      ok: false,
      message:
        e instanceof Error
          ? `Chyba při volání API: ${e.message}`
          : "Chyba při volání API.",
    };
    return Response.json(failure, { status: 500 });
  }
}

