import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "KINICON",
  description: "Vítej ve svém digitálním ateliéru",
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="cs">
      <body className="min-h-screen bg-stone-50 text-slate-900 antialiased">
        {children}
      </body>
    </html>
  );
}

