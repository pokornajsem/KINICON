export default function WalletIcon({
  className,
}: {
  className?: string;
}) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path
        d="M4.5 7.5c0-1.105.895-2 2-2h12.2c.66 0 1.2.54 1.2 1.2v.8"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
      />
      <path
        d="M4.5 9.2c0-.99.81-1.8 1.8-1.8h11.4c.99 0 1.8.81 1.8 1.8v9.3c0 .99-.81 1.8-1.8 1.8H6.3c-.99 0-1.8-.81-1.8-1.8V9.2Z"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinejoin="round"
      />
      <path
        d="M16.8 14.1h.01"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
      />
      <path
        d="M16 12.4h4"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
      />
    </svg>
  );
}

