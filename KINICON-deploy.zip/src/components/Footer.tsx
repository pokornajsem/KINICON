export default function Footer() {
  return (
    <footer className="mx-auto w-full max-w-5xl px-4 pb-10">
      <div className="rounded-3xl bg-white/60 px-5 py-4 shadow-sm ring-1 ring-stone-200 backdrop-blur">
        <div className="text-sm leading-relaxed text-slate-700">
          Vytvořeno s láskou pro všechny inovativní učitele a školy, kteří
          chtějí tvořit budoucnost moderně a s radostí. S úctou, <span className="font-bold text-teal-600">MP</span>.
        </div>
      </div>
    </footer>
  );
}

