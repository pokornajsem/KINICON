import WalletIcon from "@/components/WalletIcon";

export default function Header() {
  return (
    <header className="mx-auto w-full max-w-5xl px-4 pt-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-teal-600 text-white shadow-sm">
            <span className="text-lg font-black">K</span>
          </div>
          <div>
            <div className="text-2xl font-black tracking-tight text-teal-600">
              KINICON
            </div>
            <div className="text-xs text-slate-600">
              Kouzla pro tvořivé třídy
            </div>
          </div>
        </div>

        <div
          className="group flex items-center gap-2 rounded-full bg-white/60 px-4 py-2 shadow-sm ring-1 ring-stone-200 backdrop-blur"
          title="Video je nejsložitější kouzlo, stojí 10 tokenů. Používej ho moudře!"
        >
          <WalletIcon className="h-5 w-5 text-amber-500" />
          <span className="text-sm font-semibold text-slate-900">
            Kouzelný měšec
          </span>
          <span className="text-xs text-amber-600 opacity-80 group-hover:opacity-100">
            10
          </span>
        </div>
      </div>
    </header>
  );
}

