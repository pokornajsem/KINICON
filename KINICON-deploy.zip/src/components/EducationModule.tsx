export default function EducationModule() {
  const cards = [
    {
      title: "Impresionismus",
      desc: "Maluj „dojem“: barvy, světlo a rychlé tahy. Měj odvahu a dívej se, co se třpytí.",
    },
    {
      title: "Baroko",
      desc: "Všechno je trochu víc: stíny, drama a pohyb. Zkus udělat obrázek, co působí slavnostně.",
    },
    {
      title: "Kubismus",
      desc: "Rozděl věci na tvary. Skleň je jako puzzle a ukaž je z víc stran najednou.",
    },
  ];

  return (
    <div className="rounded-3xl bg-white/70 p-6 shadow-sm ring-1 ring-stone-200 backdrop-blur">
      <div className="flex items-center justify-between gap-4">
        <h2 className="text-xl font-bold text-slate-900 sm:text-2xl">
          Vzdělávací modul: Umělecké směry
        </h2>
        <div className="hidden rounded-2xl bg-amber-50 px-3 py-2 text-xs font-semibold text-amber-700 sm:block">
          Pro žáky 3. třídy
        </div>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-3">
        {cards.map((c) => (
          <article
            key={c.title}
            className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-stone-200"
          >
            <div className="text-base font-black text-teal-600">{c.title}</div>
            <p className="mt-2 text-sm leading-relaxed text-slate-700">
              {c.desc}
            </p>
            <div className="mt-4 h-1 w-10 rounded-full bg-amber-500" />
          </article>
        ))}
      </div>
    </div>
  );
}

