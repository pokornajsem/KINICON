"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type GenerateResponse =
  | { ok: true; message?: string; videoBase64?: string; mimeType?: string }
  | { ok: false; message: string };

function base64ToBytes(base64: string) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

export default function ImageToVideoGenerator() {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [status, setStatus] = useState<
    "idle" | "ready" | "generating" | "done" | "error"
  >("idle");
  const [message, setMessage] = useState<string>("");
  const [videoUrl, setVideoUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!file) {
      setPreviewUrl(null);
      return;
    }

    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const canGenerate = useMemo(() => status !== "generating" && file != null, [status, file]);

  async function generate() {
    if (!file) return;

    setStatus("generating");
    setMessage("");
    setVideoUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return null;
    });

    try {
      const form = new FormData();
      // API expects field name `image`.
      form.append("image", file, file.name);

      const res = await fetch("/api/image-to-video", {
        method: "POST",
        body: form,
      });

      const data = (await res.json()) as GenerateResponse;
      if (!res.ok || !("ok" in data) || data.ok !== true) {
        const msg = "message" in data ? data.message : "Neznámá chyba generování.";
        setStatus("error");
        setMessage(msg);
        return;
      }

      setStatus("done");
      setMessage(data.message ?? "");

      if (data.videoBase64) {
        const bytes = base64ToBytes(data.videoBase64);
        const blob = new Blob([bytes], { type: data.mimeType ?? "video/mp4" });
        const url = URL.createObjectURL(blob);
        setVideoUrl(url);
      }
    } catch (e) {
      setStatus("error");
      setMessage(e instanceof Error ? e.message : "Chyba při komunikaci s API.");
    }
  }

  function onFilesChosen(list: FileList | null) {
    if (!list || list.length === 0) return;
    setFile(list[0]);
    setStatus("ready");
    setMessage("");
  }

  return (
    <div className="rounded-3xl bg-white/70 p-6 shadow-sm ring-1 ring-stone-200 backdrop-blur">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900 sm:text-2xl">
            AI Rozhraní (Image-to-Video)
          </h2>
          <p className="mt-2 text-sm text-slate-700">
            „Stateless“ design: obrázky se zpracují v paměti a trvale se
            neukládají.
          </p>
        </div>
        <div className="rounded-2xl bg-amber-50 px-4 py-2 text-xs font-semibold text-amber-700">
          Video stojí 10 tokenů
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2 lg:items-start">
        <section>
          <div
            className={[
              "relative flex w-full cursor-pointer flex-col items-center justify-center rounded-3xl border-2 border-dashed p-7 text-center transition",
              isDragging
                ? "border-teal-500 bg-teal-50"
                : "border-stone-300 bg-white/60 hover:bg-white",
            ].join(" ")}
            onDragEnter={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              onFilesChosen(e.dataTransfer.files);
            }}
            onClick={() => inputRef.current?.click()}
            role="button"
            tabIndex={0}
            aria-label="Vyber obrázek"
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
            }}
          >
            <div className="text-sm font-semibold text-teal-600">
              Drag & drop sem obrázek
            </div>
            <div className="mt-2 text-xs text-slate-600">
              Nebo klikni pro výběr z disku
            </div>

            <input
              ref={inputRef}
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(e) => onFilesChosen(e.target.files)}
            />
          </div>

          <div className="mt-4 flex items-center justify-between gap-3">
            <div className="min-w-0">
              {file ? (
                <div className="text-sm text-slate-700">
                  Vybráno:{" "}
                  <span className="font-semibold text-slate-900">
                    {file.name}
                  </span>
                </div>
              ) : (
                <div className="text-sm text-slate-600">
                  Zatím nic nebylo vybráno.
                </div>
              )}
            </div>
            <button
              type="button"
              disabled={!canGenerate}
              onClick={generate}
              className={[
                "rounded-full px-5 py-2 text-sm font-semibold shadow-sm ring-1 ring-transparent transition",
                canGenerate
                  ? "bg-teal-600 text-white hover:bg-teal-700"
                  : "cursor-not-allowed bg-teal-300 text-white/80",
              ].join(" ")}
            >
              Vygenerovat video
            </button>
          </div>
        </section>

        <section>
          <div className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-stone-200">
            <div className="text-sm font-bold text-slate-900">
              Náhled a výsledek
            </div>

            <div className="mt-3">
              {previewUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={previewUrl}
                  alt="Vybraný obrázek"
                  className="max-h-60 w-full rounded-2xl object-contain ring-1 ring-stone-200"
                />
              ) : (
                <div className="flex min-h-[12rem] items-center justify-center rounded-2xl border border-dashed border-stone-200 text-sm text-slate-500">
                  Obrázek se zobrazí tady.
                </div>
              )}
            </div>

            <div className="mt-4">
              {status === "generating" ? (
                <div className="rounded-2xl bg-teal-50 p-3 text-sm text-teal-800">
                  Připravujeme video… (API stub)
                </div>
              ) : status === "error" ? (
                <div className="rounded-2xl bg-red-50 p-3 text-sm text-red-800">
                  {message}
                </div>
              ) : status === "done" ? (
                <div className="rounded-2xl bg-amber-50 p-3 text-sm text-amber-900">
                  {message || "Hotovo! (pokud je integrace nakonfigurovaná)"}
                </div>
              ) : (
                <div className="text-xs text-slate-500">
                  Nastav klíče v `.env` (nebo Vercel env) a API route bude volat
                  externí Image-to-Video službu.
                </div>
              )}
            </div>

            {videoUrl ? (
              <div className="mt-4">
                <video
                  src={videoUrl}
                  controls
                  className="h-auto w-full rounded-2xl ring-1 ring-stone-200"
                />
              </div>
            ) : null}
          </div>
        </section>
      </div>
    </div>
  );
}

