"use client";

import { useMemo, useState } from "react";
import type { ReactNode } from "react";

function ModalShell({
  open,
  title,
  children,
  onClose,
}: {
  open: boolean;
  title: string;
  children: ReactNode;
  onClose: () => void;
}) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <button
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
        onClick={onClose}
        aria-label="Zavřít"
      />
      <div className="relative w-full max-w-lg rounded-3xl bg-white p-5 shadow-xl ring-1 ring-stone-200">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="text-lg font-bold text-teal-600">{title}</div>
            <div className="mt-1 text-sm text-slate-600">
              Pro školy a učitele. V kostce a s respektem.
            </div>
          </div>
          <button
            className="rounded-xl px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-stone-100"
            onClick={onClose}
          >
            Zavřít
          </button>
        </div>

        <div className="mt-4 text-sm leading-relaxed text-slate-800">
          {children}
        </div>
      </div>
    </div>
  );
}

export default function TeacherInfoButton() {
  const [open, setOpen] = useState(false);
  const title = useMemo(() => "Info pro učitele", []);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="rounded-full bg-teal-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500"
      >
        Info pro učitele
      </button>

      <ModalShell open={open} title={title} onClose={() => setOpen(false)}>
        <p>
          <span className="font-semibold text-slate-900">Bring Your Own Tokens</span>{" "}
          znamená, že do generování jde jen to, co zadáte vy (vaše tokeny/klíče).
          Nezískáváme je, neukládáme a sami nic nesbíráme.
        </p>
        <p className="mt-3">
          <span className="font-semibold text-slate-900">Bezpečnost</span>: aplikace
          nepoužívá žádné sledování, neprofiluje děti a neukládá nahrané obrázky
          natrvalo. Zpracování probíhá v paměti (stateless) a po skončení se data
          zahodí.
        </p>
        <p className="mt-3">
          Pokud integrujete vaše API, zůstáváte v režimu „co potřebuji, to
          pošlu“ – bez sběru osobních údajů.
        </p>
      </ModalShell>
    </>
  );
}

